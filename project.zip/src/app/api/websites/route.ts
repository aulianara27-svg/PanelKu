import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/websites - List all websites
export async function GET() {
  try {
    const websites = await db.cc_Website.findMany({
      include: {
        _count: {
          select: { deployments: true, envVars: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    return NextResponse.json({
      success: true,
      data: websites
    });
  } catch (error) {
    console.error('Error fetching websites:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch websites' },
      { status: 500 }
    );
  }
}

// POST /api/websites - Create a new website
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, name, path, domain, documentRoot, phpVersion } = body;
    
    // Check if path already exists
    const existingWebsite = await db.cc_Website.findUnique({
      where: { path }
    });
    
    if (existingWebsite) {
      return NextResponse.json(
        { success: false, error: 'Website with this path already exists' },
        { status: 400 }
      );
    }
    
    const website = await db.cc_Website.create({
      data: {
        userId,
        name,
        path,
        domain,
        documentRoot: documentRoot || path,
        phpVersion: phpVersion || '8.2',
        status: 'active'
      }
    });
    
    // Create activity log
    await db.cc_ActivityLog.create({
      data: {
        userId,
        action: 'website_created',
        entity: 'website',
        entityId: website.id,
        details: JSON.stringify({ name, path })
      }
    });
    
    return NextResponse.json({
      success: true,
      data: website
    });
  } catch (error) {
    console.error('Error creating website:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create website' },
      { status: 500 }
    );
  }
}
