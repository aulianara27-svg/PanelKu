import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/services - List all services
export async function GET() {
  try {
    const services = await db.cc_Service.findMany({
      orderBy: { name: 'asc' }
    });
    
    return NextResponse.json({
      success: true,
      data: services
    });
  } catch (error) {
    console.error('Error fetching services:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch services' },
      { status: 500 }
    );
  }
}

// POST /api/services - Create a new service (for initial setup)
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, displayName, version, port } = body;
    
    const service = await db.cc_Service.create({
      data: {
        name,
        displayName,
        version,
        port,
        status: 'stopped'
      }
    });
    
    return NextResponse.json({
      success: true,
      data: service
    });
  } catch (error) {
    console.error('Error creating service:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create service' },
      { status: 500 }
    );
  }
}

// PATCH /api/services - Update service status
export async function PATCH(request: Request) {
  try {
    const body = await request.json();
    const { id, action } = body; // action: 'start', 'stop', 'restart'
    
    const service = await db.cc_Service.findUnique({
      where: { id }
    });
    
    if (!service) {
      return NextResponse.json(
        { success: false, error: 'Service not found' },
        { status: 404 }
      );
    }
    
    // In production, you would actually execute:
    // - sudo systemctl start/stop/restart {serviceName}
    
    const newStatus = action === 'stop' ? 'stopped' : 'running';
    
    const updatedService = await db.cc_Service.update({
      where: { id },
      data: {
        status: newStatus,
        lastRestart: action === 'restart' ? new Date() : service.lastRestart,
        uptime: action === 'restart' ? 0 : service.uptime
      }
    });
    
    return NextResponse.json({
      success: true,
      data: updatedService
    });
  } catch (error) {
    console.error('Error updating service:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to update service' },
      { status: 500 }
    );
  }
}
