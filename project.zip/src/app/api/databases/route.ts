import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/databases - List all databases
export async function GET() {
  try {
    const databases = await db.cc_Database.findMany({
      include: {
        _count: {
          select: { backups: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    // Remove sensitive password data
    const sanitizedDatabases = databases.map(db => ({
      ...db,
      password: '••••••••••••'
    }));
    
    return NextResponse.json({
      success: true,
      data: sanitizedDatabases
    });
  } catch (error) {
    console.error('Error fetching databases:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch databases' },
      { status: 500 }
    );
  }
}

// POST /api/databases - Create a new database
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, name, username, password, charset, collation } = body;
    
    // Check if database name already exists
    const existingDb = await db.cc_Database.findUnique({
      where: { name }
    });
    
    if (existingDb) {
      return NextResponse.json(
        { success: false, error: 'Database with this name already exists' },
        { status: 400 }
      );
    }
    
    // In production, you would:
    // 1. Create the actual MySQL database
    // 2. Create the MySQL user
    // 3. Grant permissions
    // 4. Encrypt the password before storing
    
    const database = await db.cc_Database.create({
      data: {
        userId,
        name,
        username,
        password, // In production, encrypt this!
        charset: charset || 'utf8mb4',
        collation: collation || 'utf8mb4_unicode_ci',
        status: 'active'
      }
    });
    
    // Create activity log
    await db.cc_ActivityLog.create({
      data: {
        userId,
        action: 'database_created',
        entity: 'database',
        entityId: database.id,
        details: JSON.stringify({ name })
      }
    });
    
    return NextResponse.json({
      success: true,
      data: { ...database, password: '••••••••••••' }
    });
  } catch (error) {
    console.error('Error creating database:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create database' },
      { status: 500 }
    );
  }
}
