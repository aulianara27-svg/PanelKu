import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/students - List all students with their limits and usage
export async function GET() {
  try {
    const students = await db.cc_User.findMany({
      where: { role: 'student' },
      include: {
        websites: {
          select: { id: true, name: true, path: true, status: true, diskUsage: true }
        },
        databases: {
          select: { id: true, name: true, size: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });
    
    // Get student limits
    const studentsWithLimits = await Promise.all(
      students.map(async (student) => {
        const limits = await db.cc_StudentLimit.findUnique({
          where: { userId: student.id }
        });
        
        const totalDiskUsage = student.websites.reduce((sum, w) => sum + w.diskUsage, 0);
        const totalDbSize = student.databases.reduce((sum, d) => sum + d.size, 0);
        
        return {
          ...student,
          limits: limits || {
            maxWebsites: 1,
            maxDatabases: 1,
            maxDiskSpace: 1073741824, // 1GB
            maxBandwidth: 10737418240 // 10GB
          },
          usage: {
            websites: student.websites.length,
            databases: student.databases.length,
            diskSpace: totalDiskUsage + totalDbSize,
            bandwidth: 0 // Would track this separately
          }
        };
      })
    );
    
    return NextResponse.json({
      success: true,
      data: studentsWithLimits
    });
  } catch (error) {
    console.error('Error fetching students:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch students' },
      { status: 500 }
    );
  }
}

// POST /api/students - Create a new student
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email, username, password, name, phpVersion } = body;
    
    // Check if username or email already exists
    const existingUser = await db.cc_User.findFirst({
      where: {
        OR: [
          { email },
          { username }
        ]
      }
    });
    
    if (existingUser) {
      return NextResponse.json(
        { success: false, error: 'User with this email or username already exists' },
        { status: 400 }
      );
    }
    
    // Create user with student role
    const student = await db.cc_User.create({
      data: {
        email,
        username,
        password, // In production, hash this with bcrypt!
        name,
        role: 'student',
        status: 'active'
      }
    });
    
    // Create default student limits
    await db.cc_StudentLimit.create({
      data: {
        userId: student.id,
        maxWebsites: 1,
        maxDatabases: 1,
        maxDiskSpace: 1073741824, // 1GB
        maxBandwidth: 10737418240, // 10GB
        maxCronJobs: 3,
        allowSSL: true,
        allowCustomDomain: false
      }
    });
    
    // Create path-based website for student
    const studentPath = `/student/${username}`;
    
    // In production, you would:
    // 1. Create the directory: mkdir -p /var/www/student/{username}
    // 2. Set permissions: chown -R www-data:www-data /var/www/student/{username}
    // 3. Generate Nginx config with alias
    // 4. Update .env APP_URL for the student's Laravel app
    
    const website = await db.cc_Website.create({
      data: {
        userId: student.id,
        name: `${name}'s Website`,
        path: studentPath,
        documentRoot: `/var/www${studentPath}/public`,
        phpVersion: phpVersion || '8.2',
        status: 'active'
      }
    });
    
    // Create default database for student
    const dbName = `student_${username}`;
    const dbUsername = `${username}_db`;
    
    // Generate random password for database
    const dbPassword = Array.from({ length: 16 }, () => 
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%'
    [Math.floor(Math.random() * 62)]).join('');
    
    await db.cc_Database.create({
      data: {
        userId: student.id,
        name: dbName,
        username: dbUsername,
        password: dbPassword, // In production, encrypt this!
        status: 'active'
      }
    });
    
    // Create activity log
    await db.cc_ActivityLog.create({
      data: {
        userId: student.id,
        action: 'student_created',
        entity: 'user',
        entityId: student.id,
        details: JSON.stringify({ username, email })
      }
    });
    
    return NextResponse.json({
      success: true,
      data: {
        student,
        website,
        database: { name: dbName, username: dbUsername }
      }
    });
  } catch (error) {
    console.error('Error creating student:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create student' },
      { status: 500 }
    );
  }
}
