'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, 
  Plus, 
  Search, 
  MoreVertical,
  Globe,
  Database,
  HardDrive,
  Clock,
  Mail,
  Shield,
  Key,
  Trash2,
  Edit,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Student {
  id: string;
  username: string;
  email: string;
  name: string;
  status: 'active' | 'suspended' | 'pending';
  createdAt: Date;
  lastLoginAt: Date | null;
  limits: {
    maxWebsites: number;
    maxDatabases: number;
    maxDiskSpace: number;
    maxBandwidth: number;
  };
  usage: {
    websites: number;
    databases: number;
    diskSpace: number;
    bandwidth: number;
  };
  path: string;
}

const mockStudents: Student[] = [
  {
    id: '1',
    username: 'budi123',
    email: 'budi@student.coles.id',
    name: 'Budi Santoso',
    status: 'active',
    createdAt: new Date('2024-02-15'),
    lastLoginAt: new Date('2024-03-15'),
    limits: {
      maxWebsites: 1,
      maxDatabases: 1,
      maxDiskSpace: 1073741824,
      maxBandwidth: 10737418240,
    },
    usage: {
      websites: 1,
      databases: 1,
      diskSpace: 524288000,
      bandwidth: 2147483648,
    },
    path: '/student/budi123',
  },
  {
    id: '2',
    username: 'andi456',
    email: 'andi@student.coles.id',
    name: 'Andi Wijaya',
    status: 'active',
    createdAt: new Date('2024-03-01'),
    lastLoginAt: new Date('2024-03-14'),
    limits: {
      maxWebsites: 1,
      maxDatabases: 1,
      maxDiskSpace: 1073741824,
      maxBandwidth: 10737418240,
    },
    usage: {
      websites: 1,
      databases: 1,
      diskSpace: 314572800,
      bandwidth: 1073741824,
    },
    path: '/student/andi456',
  },
  {
    id: '3',
    username: 'dewi789',
    email: 'dewi@student.coles.id',
    name: 'Dewi Lestari',
    status: 'suspended',
    createdAt: new Date('2024-03-10'),
    lastLoginAt: null,
    limits: {
      maxWebsites: 1,
      maxDatabases: 1,
      maxDiskSpace: 1073741824,
      maxBandwidth: 10737418240,
    },
    usage: {
      websites: 1,
      databases: 0,
      diskSpace: 104857600,
      bandwidth: 536870912,
    },
    path: '/student/dewi789',
  },
  {
    id: '4',
    username: 'eka101',
    email: 'eka@student.coles.id',
    name: 'Eka Prasetya',
    status: 'pending',
    createdAt: new Date('2024-03-15'),
    lastLoginAt: null,
    limits: {
      maxWebsites: 1,
      maxDatabases: 1,
      maxDiskSpace: 1073741824,
      maxBandwidth: 10737418240,
    },
    usage: {
      websites: 0,
      databases: 0,
      diskSpace: 0,
      bandwidth: 0,
    },
    path: '/student/eka101',
  },
];

const formatBytes = (bytes: number) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export function StudentManagement() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);

  const filteredStudents = mockStudents.filter(
    (student) =>
      student.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Students', value: 12, color: 'blue' },
          { label: 'Active', value: 9, color: 'green' },
          { label: 'Suspended', value: 2, color: 'yellow' },
          { label: 'Pending', value: 1, color: 'violet' },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card rounded-xl p-4"
          >
            <p className="text-sm text-gray-500">{stat.label}</p>
            <p className={cn(
              'text-2xl font-bold',
              stat.color === 'blue' && 'text-blue-400',
              stat.color === 'green' && 'text-green-400',
              stat.color === 'yellow' && 'text-yellow-400',
              stat.color === 'violet' && 'text-violet-400'
            )}>
              {stat.value}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Header Actions */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            placeholder="Search students..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-blue-500"
          />
        </div>
        <Button 
          onClick={() => setShowCreateDialog(true)}
          className="bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white border-0"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Student
        </Button>
      </div>

      {/* Student Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <AnimatePresence>
          {filteredStudents.map((student, index) => (
            <motion.div
              key={student.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ scale: 1.01 }}
              className="glass-card rounded-xl p-5 cursor-pointer"
              onClick={() => setSelectedStudent(student)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-violet-500/20 flex items-center justify-center text-white font-bold text-lg">
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold">{student.name}</h3>
                    <p className="text-xs text-gray-500">@{student.username}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge 
                    variant="outline" 
                    className={cn(
                      student.status === 'active' && 'border-green-500/30 text-green-400',
                      student.status === 'suspended' && 'border-yellow-500/30 text-yellow-400',
                      student.status === 'pending' && 'border-violet-500/30 text-violet-400'
                    )}
                  >
                    {student.status}
                  </Badge>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10">
                        <MoreVertical className="w-4 h-4 text-gray-400" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-[#0a0c10] border-blue-500/20">
                      <DropdownMenuItem className="text-gray-300 hover:text-white hover:bg-white/5">
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Details
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-gray-300 hover:text-white hover:bg-white/5">
                        <Key className="w-4 h-4 mr-2" />
                        Reset Password
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-gray-300 hover:text-white hover:bg-white/5">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View Website
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-white/10" />
                      <DropdownMenuItem className="text-red-400 hover:text-red-300 hover:bg-red-500/10">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete Student
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              {/* Path Info */}
              <div className="p-2 rounded-lg bg-black/30 border border-white/5 mb-4">
                <code className="text-xs text-green-400">coles.id{student.path}</code>
              </div>

              {/* Resource Usage */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400 flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    Websites
                  </span>
                  <span className="text-white">
                    {student.usage.websites} / {student.limits.maxWebsites}
                  </span>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400 flex items-center gap-2">
                    <Database className="w-4 h-4" />
                    Databases
                  </span>
                  <span className="text-white">
                    {student.usage.databases} / {student.limits.maxDatabases}
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-gray-400 flex items-center gap-2">
                      <HardDrive className="w-4 h-4" />
                      Disk Space
                    </span>
                    <span className="text-white">
                      {formatBytes(student.usage.diskSpace)} / {formatBytes(student.limits.maxDiskSpace)}
                    </span>
                  </div>
                  <Progress 
                    value={(student.usage.diskSpace / student.limits.maxDiskSpace) * 100}
                    className="h-1.5"
                  />
                </div>
              </div>

              {/* Footer Info */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5 text-xs text-gray-500">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  Joined {student.createdAt.toLocaleDateString()}
                </span>
                {student.lastLoginAt && (
                  <span>Last login: {student.lastLoginAt.toLocaleDateString()}</span>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Create Student Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-md bg-[#0a0c10] border-blue-500/20">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              Add New Student
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Create a new student account with path-based hosting
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-gray-300">Username</Label>
                <Input
                  id="username"
                  placeholder="e.g., budi123"
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name" className="text-gray-300">Full Name</Label>
                <Input
                  id="name"
                  placeholder="e.g., Budi Santoso"
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-300">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="student@example.com"
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300">PHP Version</Label>
              <Select defaultValue="8.2">
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0a0c10] border-blue-500/20">
                  <SelectItem value="8.3">PHP 8.3 (Latest)</SelectItem>
                  <SelectItem value="8.2">PHP 8.2 (Recommended)</SelectItem>
                  <SelectItem value="8.1">PHP 8.1</SelectItem>
                  <SelectItem value="8.0">PHP 8.0</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20">
              <p className="text-xs text-blue-400">
                The student's website will be accessible at:
              </p>
              <code className="text-sm text-white font-mono">
                coles.id/student/[username]
              </code>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" className="border-white/10 text-gray-300" onClick={() => setShowCreateDialog(false)}>
              Cancel
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-500 text-white">
              Create Student
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Student Detail Dialog */}
      <Dialog open={!!selectedStudent} onOpenChange={() => setSelectedStudent(null)}>
        <DialogContent className="max-w-2xl bg-[#0a0c10] border-blue-500/20">
          {selectedStudent && (
            <>
              <DialogHeader>
                <DialogTitle className="text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-blue-400" />
                  {selectedStudent.name}
                </DialogTitle>
                <DialogDescription className="text-gray-400">
                  Student details and resource usage
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4 py-4">
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Username</p>
                    <p className="text-white">@{selectedStudent.username}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Email</p>
                    <p className="text-white flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      {selectedStudent.email}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Website Path</p>
                    <code className="text-green-400 text-sm">
                      coles.id{selectedStudent.path}
                    </code>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Status</p>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        selectedStudent.status === 'active' && 'border-green-500/30 text-green-400',
                        selectedStudent.status === 'suspended' && 'border-yellow-500/30 text-yellow-400',
                        selectedStudent.status === 'pending' && 'border-violet-500/30 text-violet-400'
                      )}
                    >
                      {selectedStudent.status}
                    </Badge>
                  </div>
                  <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                    <p className="text-xs text-gray-500 mb-2">Resource Usage</p>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Websites</span>
                        <span className="text-white">{selectedStudent.usage.websites}/{selectedStudent.limits.maxWebsites}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Databases</span>
                        <span className="text-white">{selectedStudent.usage.databases}/{selectedStudent.limits.maxDatabases}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Disk</span>
                        <span className="text-white">{formatBytes(selectedStudent.usage.diskSpace)}/{formatBytes(selectedStudent.limits.maxDiskSpace)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex gap-3 justify-end">
                <Button variant="outline" className="border-white/10 text-gray-300">
                  Close
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-500 text-white">
                  Edit Student
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
