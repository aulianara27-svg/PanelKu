'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, 
  Send, 
  Bot, 
  User, 
  Lightbulb,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Copy,
  ThumbsUp,
  ThumbsDown,
  Terminal,
  Code,
  FileText,
} from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actions?: {
    type: 'fix' | 'command' | 'suggestion';
    label: string;
    data: string;
  }[];
}

const initialMessages: Message[] = [
  {
    id: '1',
    role: 'assistant',
    content: 'Hello! I\'m your AI Assistant for COLES CONTROL. I can help you with:\n\n• **Server troubleshooting** - Diagnose and fix errors\n• **Configuration help** - Nginx, PHP-FPM, MySQL settings\n• **Code assistance** - Debug and optimize your applications\n• **Security advice** - Best practices for your server\n\nHow can I help you today?',
    timestamp: new Date(Date.now() - 60000),
  },
];

const suggestedPrompts = [
  { icon: AlertTriangle, text: 'Diagnose 500 error on student/budi123', color: 'red' },
  { icon: Code, text: 'Optimize my Nginx configuration', color: 'blue' },
  { icon: Terminal, text: 'Help me set up SSL for coles.id', color: 'green' },
  { icon: FileText, text: 'Explain Laravel queue workers', color: 'violet' },
];

const mockResponses: Record<string, Message> = {
  'error': {
    id: 'r1',
    role: 'assistant',
    content: 'I found the issue! The **500 Internal Server Error** on `student/budi123` is caused by:\n\n```\nParseError: syntax error, unexpected \'}\'\nFile: /var/www/student/budi123/app/Http/Controllers/HomeController.php:42\n```\n\n**Quick Fix Available:** I can automatically correct this syntax error for you.',
    timestamp: new Date(),
    actions: [
      { type: 'fix', label: 'One-Click Repair', data: 'fix:syntax:/var/www/student/budi123/app/Http/Controllers/HomeController.php' },
    ],
  },
  'default': {
    id: 'r2',
    role: 'assistant',
    content: 'I understand you need help. Let me analyze your request and provide the best solution.\n\nBased on your current server configuration:\n\n• **CPU Usage:** 42% (Normal)\n• **Memory:** 3.2GB / 8GB (Normal)\n• **Disk:** 45% (Normal)\n\nEverything looks healthy! What specific task would you like me to help with?',
    timestamp: new Date(),
  },
};

export function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const response = inputValue.toLowerCase().includes('error') 
        ? mockResponses['error'] 
        : mockResponses['default'];
      
      const aiMessage: Message = {
        ...response,
        id: Date.now().toString(),
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleAction = (action: Message['actions'] extends (infer T)[] | undefined ? T : never) => {
    if (action?.type === 'fix') {
      // Simulate fix action
      const fixMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: `✅ **Fix Applied Successfully!**\n\nI've corrected the syntax error in \`HomeController.php\`:\n\n- **Fixed:** Missing semicolon on line 41\n- **Status:** Deployed\n- **Backup:** Created at \`/var/www/student/budi123/backups/2024-03-15/\`\n\nThe website should now be working. Please verify by visiting the URL.`,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, fixMessage]);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="h-[calc(100vh-200px)] flex flex-col"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-[#0a0c10] animate-pulse" />
          </div>
          <div>
            <h2 className="text-white font-semibold">AI Assistant</h2>
            <p className="text-xs text-gray-500">Powered by Gemini</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10">
            <RefreshCw className="w-4 h-4 text-gray-400" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-white/10">
            <Terminal className="w-4 h-4 text-gray-400" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence mode="popLayout">
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ delay: index * 0.05 }}
              className={cn(
                'flex gap-3',
                message.role === 'user' ? 'flex-row-reverse' : ''
              )}
            >
              <div className={cn(
                'w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0',
                message.role === 'assistant'
                  ? 'bg-gradient-to-br from-violet-600 to-blue-600'
                  : 'bg-gray-700'
              )}>
                {message.role === 'assistant' ? (
                  <Bot className="w-4 h-4 text-white" />
                ) : (
                  <User className="w-4 h-4 text-white" />
                )}
              </div>
              <div className={cn(
                'max-w-[80%] rounded-xl p-4',
                message.role === 'assistant'
                  ? 'bg-white/5 border border-white/10'
                  : 'bg-blue-600/20 border border-blue-500/30'
              )}>
                <div className="text-sm text-gray-200 whitespace-pre-wrap">
                  {message.content.split('```').map((part, i) => {
                    if (i % 2 === 1) {
                      return (
                        <div key={i} className="my-2 relative">
                          <pre className="p-3 rounded-lg bg-black/40 text-green-400 text-xs font-mono overflow-x-auto">
                            {part}
                          </pre>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute top-2 right-2 h-6 w-6 hover:bg-white/10"
                          >
                            <Copy className="w-3 h-3 text-gray-400" />
                          </Button>
                        </div>
                      );
                    }
                    return <span key={i}>{part}</span>;
                  })}
                </div>
                
                {message.actions && message.actions.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-white/10 space-y-2">
                    {message.actions.map((action, i) => (
                      <Button
                        key={i}
                        onClick={() => handleAction(action)}
                        className={cn(
                          'w-full',
                          action.type === 'fix' && 'bg-green-600 hover:bg-green-500 text-white',
                          action.type === 'command' && 'bg-blue-600 hover:bg-blue-500 text-white',
                          action.type === 'suggestion' && 'bg-violet-600 hover:bg-violet-500 text-white'
                        )}
                      >
                        {action.type === 'fix' && <CheckCircle className="w-4 h-4 mr-2" />}
                        {action.type === 'command' && <Terminal className="w-4 h-4 mr-2" />}
                        {action.type === 'suggestion' && <Lightbulb className="w-4 h-4 mr-2" />}
                        {action.label}
                      </Button>
                    ))}
                  </div>
                )}
                
                <div className="flex items-center justify-between mt-3 pt-2 border-t border-white/5">
                  <span className="text-xs text-gray-500">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                  {message.role === 'assistant' && (
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/10">
                        <ThumbsUp className="w-3 h-3 text-gray-500" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/10">
                        <ThumbsDown className="w-3 h-3 text-gray-500" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-white/10">
                        <Copy className="w-3 h-3 text-gray-500" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-3"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-white/5 border border-white/10 rounded-xl px-4 py-3">
              <div className="flex items-center gap-1">
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 1, repeat: Infinity, delay: 0 }}
                  className="w-2 h-2 rounded-full bg-violet-400"
                />
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 1, repeat: Infinity, delay: 0.2 }}
                  className="w-2 h-2 rounded-full bg-violet-400"
                />
                <motion.div
                  animate={{ opacity: [0.4, 1, 0.4] }}
                  transition={{ duration: 1, repeat: Infinity, delay: 0.4 }}
                  className="w-2 h-2 rounded-full bg-violet-400"
                />
              </div>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts */}
      {messages.length === 1 && (
        <div className="px-4 pb-2">
          <p className="text-xs text-gray-500 mb-2">Suggested prompts:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => setInputValue(prompt.text)}
                className={cn(
                  'flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all',
                  'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 hover:text-white',
                  prompt.color === 'red' && 'hover:border-red-500/30',
                  prompt.color === 'blue' && 'hover:border-blue-500/30',
                  prompt.color === 'green' && 'hover:border-green-500/30',
                  prompt.color === 'violet' && 'hover:border-violet-500/30'
                )}
              >
                <prompt.icon className="w-4 h-4" />
                {prompt.text}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-white/10">
        <div className="flex gap-2">
          <Input
            placeholder="Ask anything about your server..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-violet-500"
          />
          <Button
            onClick={handleSend}
            disabled={!inputValue.trim() || isTyping}
            className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 text-white border-0"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          AI can read logs, diagnose errors, and suggest fixes. Always review changes before applying.
        </p>
      </div>
    </motion.div>
  );
}
